﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace PPERP
{
    public partial class frm6SqlCommand : Form
    {
        public frm6SqlCommand()
        {
            InitializeComponent();
        }

        //執行命令按鈕
        private void btnExecute_Click(object sender, EventArgs e)
        {
            //1. 建立資料庫連線

            //2. 宣告與設定SQLCommand元件: 連線與要執行的SQL命令

            //3. 執行SQL命令

        }

        private void btnSelect_Click(object sender, EventArgs e)
        {


        }
    }
}
